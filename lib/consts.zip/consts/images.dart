const String clouds = "assets/icons/clouds.png";
const String humidity = "assets/icons/humidity.png";
const String windspeed = "assets/icons/windspeed.png";
