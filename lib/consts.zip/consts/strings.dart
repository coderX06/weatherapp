const String degree = "°";
const String apiKey = "83a03dbe410ee9b9414d1e7f2ed37ed9";
const String currentEndpoint = "https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API key}";
const String daysEndpoint = "api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={API key}";
const String forecast="api.openweathermap.org/data/2.5/forecast/daily?lat={lat}&lon={lon}&cnt={cnt}&appid={API key}";
const String cityapi="https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}";


String Latitude="52.5244";
String Longitude="13.4105";
String cnt="10";


